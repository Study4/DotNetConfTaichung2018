﻿using Microsoft.AspNetCore.Authorization;

namespace AuthorizationPolicies
{
    public class MicrosoftOnlyRequirement : IAuthorizationRequirement
    {
    }
}
